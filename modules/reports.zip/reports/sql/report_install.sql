CREATE TABLE IF NOT EXISTS `c19_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_name` char(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

